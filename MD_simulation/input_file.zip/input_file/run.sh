#Minimization
pmemd.cuda -O -i min.in -o com_min.out -p com-sol.prmtop -c com-sol.rst7  -r com_min.rst7  -ref com-sol.rst7
ambpdb -p com-sol.prmtop -c com_min.rst7 > com_min.pdb

# Heating
pmemd.cuda -O -i heat.in -o heat.out -p com-sol.prmtop -c com_min.rst7 -r heat.rst7 -x heat.nc -ref com_min.rst7
ambpdb -p com-sol.prmtop -c heat.rst7 > heat.pdb

# Equilibration
pmemd.cuda -O -i equ1.in -o equ1.out -p com-sol.prmtop -c heat.rst7 -r equ1.rst7 -x equ1.nc -ref heat.rst7
pmemd.cuda -O -i equ2.in -o equ2.out -p com-sol.prmtop -c equ1.rst7 -r equ2.rst7 -x equ2.nc -ref equ1.rst7
pmemd.cuda -O -i equ3.in -o equ3.out -p com-sol.prmtop -c equ2.rst7 -r equ3.rst7 -x equ3.nc -ref equ2.rst7
pmemd.cuda -O -i equ4.in -o equ4.out -p com-sol.prmtop -c equ3.rst7 -r equ4.rst7 -x equ4.nc -ref equ3.rst7
pmemd.cuda -O -i equ5.in -o equ5.out -p com-sol.prmtop -c equ4.rst7 -r equ5.rst7 -x equ5.nc -ref equ4.rst7
ambpdb -p com-sol.prmtop -c equ5.rst7 > equ5.pdb

# Production
pmemd.cuda -O -i prod.in -o prod.out -p com-sol.prmtop -c equ5.rst7 -r prod.rst7 -x prod.nc -ref equ5.rst7
ambpdb -p com-sol.prmtop -c prod.rst7 > prod.pdb
